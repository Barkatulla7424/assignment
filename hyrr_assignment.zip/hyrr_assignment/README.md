# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh
This project is a simple implementation of a credit card form with validation for the card type, card number, and expiration date fields. The project includes the following files:

index.html: The main HTML file that includes the form and error messages.
styles.css: The CSS file that styles the form and error messages.
script.js: The JavaScript file that validates the form fields and displays error messages.
How to Use
Open the index.html file in a web browser.
Enter the valid information for the card type, card number, and expiration date fields.
If the information is invalid, an error message will be displayed for each field.
If the information is valid, the form will be submitted.
How to Customize
You can customize the project by modifying the index.html, styles.css, and script.js files. For example, you can add additional form fields, error messages, or other HTML elements. You can also customize the styles using CSS, and you can modify the validation logic using JavaScript.

Requirements
This project requires a modern web browser that supports HTML5, CSS3, and JavaScript. The project has been tested in Google Chrome and Mozilla Firefox.