const config = {
    formValidator: {
      creditCardForm: {
        inputs: [
          {
            name: "ccType",
            isMandatory: true,
            pattern: "^(Visa|MasterCard|American Express)$",
            errorMessage: "Invalid credit card type",
          },
          {
            name: "ccNum",
            isMandatory: true,
            pattern: "^\\d{13,16}$",
            errorMessage: "Invalid credit card number",
          },
          {
            name: "ccExp",
            isMandatory: true,
            pattern: "^(0[1-9]|1[0-2])/\\d{2}$",
            errorMessage: "Invalid credit card expiration date",
          },
        ],
      },
    },
  };
  
  module.exports = config;